DROP POLICY IF EXISTS "profiles_public_read" ON public.profiles;
REVOKE SELECT ON public.profiles FROM anon;

CREATE OR REPLACE FUNCTION public.get_public_profile(_slug text)
RETURNS TABLE (
  id uuid,
  slug text,
  display_name text,
  social_handle text,
  tagline text,
  avatar_path text,
  welcome_video_path text,
  background_video_path text,
  background_image_path text,
  theme text,
  links jsonb,
  capture_enabled boolean,
  capture_heading text,
  is_published boolean
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    p.id,
    p.slug,
    p.display_name,
    p.social_handle,
    p.tagline,
    p.avatar_path,
    p.welcome_video_path,
    p.background_video_path,
    p.background_image_path,
    p.theme,
    p.links,
    p.capture_enabled,
    p.capture_heading,
    p.is_published
  FROM public.profiles AS p
  WHERE p.slug = lower(trim(_slug))
    AND p.is_published
    AND p.plan <> 'none'
    AND p.subscription_status IN ('trialing', 'active', 'past_due')
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.get_public_profile(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_profile(text) TO anon, authenticated, service_role;