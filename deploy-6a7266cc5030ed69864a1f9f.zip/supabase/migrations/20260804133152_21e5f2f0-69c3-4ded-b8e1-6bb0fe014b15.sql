REVOKE ALL ON FUNCTION public.subscribe_to_profile(text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.protect_profile_billing_fields() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;
CREATE POLICY "stripe_events_service_only" ON public.stripe_events FOR ALL TO service_role USING (true) WITH CHECK (true);