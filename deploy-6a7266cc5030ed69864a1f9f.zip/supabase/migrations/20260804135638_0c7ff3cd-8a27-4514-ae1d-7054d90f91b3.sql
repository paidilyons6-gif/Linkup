DROP FUNCTION IF EXISTS public.get_public_profile(text);

CREATE TABLE public.public_profiles (
  id uuid PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  slug text UNIQUE,
  display_name text NOT NULL DEFAULT '',
  social_handle text NOT NULL DEFAULT '',
  tagline text NOT NULL DEFAULT '',
  avatar_path text,
  welcome_video_path text,
  background_video_path text,
  background_image_path text,
  theme text NOT NULL DEFAULT 'blush',
  links jsonb NOT NULL DEFAULT '[]'::jsonb,
  capture_enabled boolean NOT NULL DEFAULT false,
  capture_heading text NOT NULL DEFAULT 'Join my email list',
  is_published boolean NOT NULL DEFAULT false,
  is_active boolean NOT NULL DEFAULT false
);
GRANT SELECT ON public.public_profiles TO anon, authenticated;
GRANT ALL ON public.public_profiles TO service_role;
ALTER TABLE public.public_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_profiles_public_read" ON public.public_profiles
  FOR SELECT TO anon, authenticated
  USING (is_published AND is_active);
CREATE POLICY "public_profiles_owner_read" ON public.public_profiles
  FOR SELECT TO authenticated
  USING (id = auth.uid());

CREATE OR REPLACE FUNCTION public.sync_public_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.public_profiles (
    id, slug, display_name, social_handle, tagline,
    avatar_path, welcome_video_path, background_video_path, background_image_path,
    theme, links, capture_enabled, capture_heading, is_published, is_active
  ) VALUES (
    NEW.id, NEW.slug, NEW.display_name, NEW.social_handle, NEW.tagline,
    NEW.avatar_path, NEW.welcome_video_path, NEW.background_video_path, NEW.background_image_path,
    NEW.theme, NEW.links, NEW.capture_enabled, NEW.capture_heading, NEW.is_published,
    NEW.plan <> 'none' AND NEW.subscription_status IN ('trialing', 'active', 'past_due')
  )
  ON CONFLICT (id) DO UPDATE SET
    slug = EXCLUDED.slug,
    display_name = EXCLUDED.display_name,
    social_handle = EXCLUDED.social_handle,
    tagline = EXCLUDED.tagline,
    avatar_path = EXCLUDED.avatar_path,
    welcome_video_path = EXCLUDED.welcome_video_path,
    background_video_path = EXCLUDED.background_video_path,
    background_image_path = EXCLUDED.background_image_path,
    theme = EXCLUDED.theme,
    links = EXCLUDED.links,
    capture_enabled = EXCLUDED.capture_enabled,
    capture_heading = EXCLUDED.capture_heading,
    is_published = EXCLUDED.is_published,
    is_active = EXCLUDED.is_active;
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.sync_public_profile() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.sync_public_profile() TO service_role;

CREATE TRIGGER profiles_sync_public
AFTER INSERT OR UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.sync_public_profile();

INSERT INTO public.public_profiles (
  id, slug, display_name, social_handle, tagline,
  avatar_path, welcome_video_path, background_video_path, background_image_path,
  theme, links, capture_enabled, capture_heading, is_published, is_active
)
SELECT
  id, slug, display_name, social_handle, tagline,
  avatar_path, welcome_video_path, background_video_path, background_image_path,
  theme, links, capture_enabled, capture_heading, is_published,
  plan <> 'none' AND subscription_status IN ('trialing', 'active', 'past_due')
FROM public.profiles;