CREATE TYPE public.linkup_plan AS ENUM ('none', 'basic', 'premium', 'business');
CREATE TYPE public.subscription_state AS ENUM ('inactive', 'trialing', 'active', 'past_due', 'canceled', 'unpaid');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  slug text UNIQUE,
  display_name text NOT NULL DEFAULT '',
  social_handle text NOT NULL DEFAULT '',
  tagline text NOT NULL DEFAULT '',
  avatar_path text,
  welcome_video_path text,
  background_video_path text,
  background_image_path text,
  theme text NOT NULL DEFAULT 'blush' CHECK (theme IN ('blush','midnight','sage','amber','ink')),
  links jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(links) = 'array' AND jsonb_array_length(links) <= 30),
  capture_enabled boolean NOT NULL DEFAULT false,
  capture_heading text NOT NULL DEFAULT 'Join my email list',
  is_published boolean NOT NULL DEFAULT false,
  plan public.linkup_plan NOT NULL DEFAULT 'none',
  subscription_status public.subscription_state NOT NULL DEFAULT 'inactive',
  stripe_customer_id text UNIQUE,
  stripe_subscription_id text UNIQUE,
  stripe_price_id text,
  current_period_end timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT profiles_slug_format CHECK (slug IS NULL OR slug ~ '^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])?$'),
  CONSTRAINT profiles_slug_reserved CHECK (slug IS NULL OR slug <> ALL (ARRAY['admin','api','auth','account','billing','dashboard','edit','help','login','logout','privacy','reset-password','settings','signin','signup','terms','unsubscribe','www']))
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT SELECT ON public.profiles TO anon;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_owner_read" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid());
CREATE POLICY "profiles_public_read" ON public.profiles FOR SELECT TO anon, authenticated USING (is_published AND plan <> 'none' AND subscription_status IN ('trialing','active','past_due'));
CREATE POLICY "profiles_owner_insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid() AND plan = 'none' AND subscription_status = 'inactive' AND stripe_customer_id IS NULL AND stripe_subscription_id IS NULL AND stripe_price_id IS NULL AND current_period_end IS NULL AND is_published = false);
CREATE POLICY "profiles_owner_update" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_owner_delete" ON public.profiles FOR DELETE TO authenticated USING (id = auth.uid());

CREATE TABLE public.subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  email text NOT NULL CHECK (char_length(email) BETWEEN 3 AND 320),
  consented_at timestamptz NOT NULL DEFAULT now(),
  unsubscribed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (profile_id, email)
);
GRANT SELECT, UPDATE, DELETE ON public.subscribers TO authenticated;
GRANT ALL ON public.subscribers TO service_role;
ALTER TABLE public.subscribers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "subscribers_owner_read" ON public.subscribers FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = profile_id AND p.id = auth.uid()));
CREATE POLICY "subscribers_owner_update" ON public.subscribers FOR UPDATE TO authenticated USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = profile_id AND p.id = auth.uid())) WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = profile_id AND p.id = auth.uid()));
CREATE POLICY "subscribers_owner_delete" ON public.subscribers FOR DELETE TO authenticated USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = profile_id AND p.id = auth.uid()));

CREATE TABLE public.stripe_events (
  event_id text PRIMARY KEY,
  event_type text NOT NULL,
  processed_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.stripe_events TO service_role;
ALTER TABLE public.stripe_events ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER profiles_set_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER subscribers_set_updated_at BEFORE UPDATE ON public.subscribers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.protect_profile_billing_fields()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND auth.role() <> 'service_role' THEN
    NEW.plan := OLD.plan;
    NEW.subscription_status := OLD.subscription_status;
    NEW.stripe_customer_id := OLD.stripe_customer_id;
    NEW.stripe_subscription_id := OLD.stripe_subscription_id;
    NEW.stripe_price_id := OLD.stripe_price_id;
    NEW.current_period_end := OLD.current_period_end;
    IF NEW.plan = 'none' OR NEW.subscription_status NOT IN ('trialing','active','past_due') THEN NEW.is_published := false; END IF;
    IF NEW.plan NOT IN ('premium','business') THEN NEW.welcome_video_path := NULL; END IF;
    IF NEW.plan <> 'business' THEN NEW.capture_enabled := false; END IF;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER profiles_protect_billing BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.protect_profile_billing_fields();

CREATE OR REPLACE FUNCTION public.subscribe_to_profile(_slug text, _email text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target_id uuid;
BEGIN
  IF _email IS NULL OR char_length(trim(_email)) < 3 OR char_length(trim(_email)) > 320 OR trim(_email) !~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$' THEN
    RAISE EXCEPTION 'Invalid email address';
  END IF;
  SELECT id INTO target_id FROM public.profiles WHERE slug = lower(trim(_slug)) AND is_published AND plan = 'business' AND subscription_status IN ('trialing','active','past_due') AND capture_enabled;
  IF target_id IS NULL THEN RETURN false; END IF;
  INSERT INTO public.subscribers(profile_id, email, consented_at, unsubscribed_at)
  VALUES (target_id, lower(trim(_email)), now(), NULL)
  ON CONFLICT (profile_id, email) DO UPDATE SET consented_at = now(), unsubscribed_at = NULL;
  RETURN true;
END;
$$;
GRANT EXECUTE ON FUNCTION public.subscribe_to_profile(text,text) TO anon, authenticated;

CREATE POLICY "profile_media_owner_read" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'profile-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "profile_media_owner_insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'profile-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "profile_media_owner_update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'profile-media' AND (storage.foldername(name))[1] = auth.uid()::text) WITH CHECK (bucket_id = 'profile-media' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "profile_media_owner_delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'profile-media' AND (storage.foldername(name))[1] = auth.uid()::text);