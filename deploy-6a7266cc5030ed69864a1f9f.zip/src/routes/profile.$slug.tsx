import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { PublicProfile, type ProfileMediaUrls } from "@/components/public-profile";
import { supabase } from "@/integrations/supabase/client";
import { getPublicMediaUrls } from "@/lib/media.functions";
import type { PublicProfileRow } from "@/lib/profile";

export const Route = createFileRoute("/profile/$slug")({
  head: ({ params }) => ({ meta: [{ title: `${params.slug} on LinkUp` }, { name: "description", content: "A creator page made with LinkUp." }, { property: "og:title", content: `${params.slug} on LinkUp` }, { property: "og:description", content: "A creator page made with LinkUp." }, { property: "og:type", content: "profile" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: PublicProfileRoute,
});

function PublicProfileRoute() {
  const { slug } = Route.useParams();
  const [profile, setProfile] = useState<PublicProfileRow | null>();
  const [mediaUrls, setMediaUrls] = useState<ProfileMediaUrls>({});
  const resolveMedia = useServerFn(getPublicMediaUrls);
  useEffect(() => { void supabase.from("public_profiles").select("id, slug, display_name, social_handle, tagline, avatar_path, welcome_video_path, background_video_path, background_image_path, theme, links, capture_enabled, capture_heading, is_published, is_active").eq("slug", slug).eq("is_published", true).eq("is_active", true).maybeSingle().then(({ data }) => setProfile(data)); }, [slug]);
  useEffect(() => { void resolveMedia({ data: { slug } }).then((data) => setMediaUrls(data)); }, [resolveMedia, slug]);
  if (profile === undefined) return <div className="grid min-h-screen place-items-center bg-background text-muted-foreground">Opening page…</div>;
  if (!profile) return <div className="grid min-h-screen place-items-center bg-background px-6 text-center"><div><h1 className="font-serif text-4xl font-bold">Nothing here yet.</h1><p className="mt-3 text-muted-foreground">This LinkUp page may not be published.</p><Link to="/" className="mt-6 inline-block font-semibold text-primary">Go to LinkUp</Link></div></div>;
  return <PublicProfile profile={profile} mediaUrls={mediaUrls} />;
}