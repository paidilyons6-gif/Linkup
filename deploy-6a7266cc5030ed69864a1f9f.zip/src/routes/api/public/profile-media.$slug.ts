import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/profile-media/$slug")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: profile, error } = await supabaseAdmin
          .from("profiles")
          .select("avatar_path,background_image_path,background_video_path,welcome_video_path")
          .eq("slug", params.slug)
          .eq("is_published", true)
          .neq("plan", "none")
          .in("subscription_status", ["trialing", "active", "past_due"])
          .maybeSingle();

        if (error) return Response.json({ error: "Media could not be loaded" }, { status: 500 });
        if (!profile) return Response.json({});

        const entries = Object.entries(profile).filter(
          (entry): entry is [keyof typeof profile, string] => typeof entry[1] === "string",
        );
        const resolved = await Promise.all(
          entries.map(async ([key, path]) => {
            const { data: signed } = await supabaseAdmin.storage
              .from("profile-media")
              .createSignedUrl(path, 3600);
            return [key, signed?.signedUrl] as const;
          }),
        );

        return Response.json(Object.fromEntries(resolved.filter((entry) => Boolean(entry[1]))), {
          headers: { "cache-control": "public, max-age=300" },
        });
      },
    },
  },
});