import { createFileRoute } from "@tanstack/react-router";
import type Stripe from "stripe";
import { planFromPrice, stripeForWebhook } from "@/lib/billing.server";

export const Route = createFileRoute("/api/public/stripe/webhook")({
  server: { handlers: { POST: async ({ request }) => {
    const signature = request.headers.get("stripe-signature");
    const secret = process.env["STRIPE_WEBHOOK_SECRET"];
    if (!signature || !secret) return new Response("Webhook not configured", { status: 400 });
    let event: Stripe.Event;
    try { event = stripeForWebhook().webhooks.constructEvent(await request.text(), signature, secret); }
    catch { return new Response("Invalid signature", { status: 400 }); }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: prior } = await supabaseAdmin.from("stripe_events").select("event_id").eq("event_id", event.id).maybeSingle();
    if (prior) return Response.json({ received: true });

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.client_reference_id ?? session.metadata?.["user_id"];
      if (userId && typeof session.customer === "string") await supabaseAdmin.from("profiles").update({ stripe_customer_id: session.customer }).eq("id", userId);
    }
    if (event.type.startsWith("customer.subscription.")) {
      const subscription = event.data.object as Stripe.Subscription;
      const userId = subscription.metadata["user_id"];
      const priceId = subscription.items.data[0]?.price.id ?? "";
      const active = ["active", "trialing", "past_due"].includes(subscription.status);
      const supportedStatus = ["inactive", "trialing", "active", "past_due", "canceled", "unpaid"] as const;
      const status = supportedStatus.find((value) => value === subscription.status) ?? "inactive";
      if (userId) await supabaseAdmin.from("profiles").update({
        plan: active ? planFromPrice(priceId) : "none",
        subscription_status: status,
        stripe_customer_id: typeof subscription.customer === "string" ? subscription.customer : subscription.customer.id,
        stripe_subscription_id: subscription.id,
        stripe_price_id: priceId,
        current_period_end: subscription.items.data[0]?.current_period_end ? new Date(subscription.items.data[0].current_period_end * 1000).toISOString() : null,
      }).eq("id", userId);
    }
    await supabaseAdmin.from("stripe_events").insert({ event_id: event.id, event_type: event.type });
    return Response.json({ received: true });
  } } },
});