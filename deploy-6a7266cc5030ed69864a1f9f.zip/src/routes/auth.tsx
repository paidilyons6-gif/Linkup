import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { z } from "zod";
import { Brand } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { lovable } from "@/integrations/lovable";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  validateSearch: z.object({ mode: z.enum(["signup", "signin"]).optional() }),
  head: () => ({ meta: [{ title: "Create your LinkUp account" }, { name: "description", content: "Sign up or sign in to build your LinkUp page." }, { property: "og:title", content: "Create your LinkUp account" }, { property: "og:description", content: "Build your personal link page and publish when ready." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const [mode, setMode] = useState<"signup" | "signin" | "forgot" | "recover">(search.mode ?? "signup");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (window.location.hash.includes("type=recovery")) {
      setMode("recover");
      return;
    }

    let active = true;
    void supabase.auth.getUser().then(({ data }) => {
      if (active && data.user) void navigate({ to: "/dashboard", replace: true });
    });
    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      if (active && (event === "SIGNED_IN" || event === "USER_UPDATED") && session?.user) {
        void navigate({ to: "/dashboard", replace: true });
      }
    });
    return () => {
      active = false;
      listener.subscription.unsubscribe();
    };
  }, [navigate]);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("");
    const form = new FormData(event.currentTarget); const email = String(form.get("email")); const password = String(form.get("password"));
    if (mode === "forgot") { const result = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/auth` }); setBusy(false); return setMessage(result.error?.message ?? "If that address has an account, a reset link is on its way."); }
    if (mode === "recover") { const result = await supabase.auth.updateUser({ password }); setBusy(false); if (result.error) return setMessage(result.error.message); setMessage("Password saved. You can continue to your editor."); return; }
    const result = mode === "signup" ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/auth?mode=signin` } }) : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (result.error) return setMessage(result.error.message);
    if (mode === "signup" && !result.data.session) return setMessage("Check your email to confirm your address, then sign in.");
    void navigate({ to: "/dashboard" });
  }
  async function google() {
    setBusy(true);
    setMessage("");
    try {
      const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: `${window.location.origin}/auth?mode=signin` });
      if (result.error) setMessage(result.error.message);
      else if (!result.redirected) void navigate({ to: "/dashboard", replace: true });
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Google sign-in could not start. Please try again.");
    } finally {
      setBusy(false);
    }
  }
  return <main className="auth-page"><div className="auth-card"><Brand /><p className="mt-8 text-xs font-bold uppercase tracking-[0.16em] text-primary">Your page starts here</p><h1 className="mt-2 font-serif text-4xl font-bold">{mode === "signup" ? "Create your account" : mode === "signin" ? "Welcome back" : mode === "forgot" ? "Reset your password" : "Choose a new password"}</h1><p className="mt-2 text-sm text-muted-foreground">{mode === "forgot" ? "We’ll email you a secure reset link." : mode === "recover" ? "Use at least eight characters." : "Free to build. Pick a plan when you're ready to publish."}</p>{(mode === "signup" || mode === "signin") && <><Button type="button" variant="outline" className="mt-7 w-full" disabled={busy} onClick={google}>{busy ? "Connecting…" : "Continue with Google"}</Button><div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />or use email<span className="h-px flex-1 bg-border" /></div></>}<form onSubmit={submit} className="space-y-4">{mode !== "recover" && <label className="field-label">Email<input name="email" type="email" required autoComplete="email" /></label>}{mode !== "forgot" && <label className="field-label">Password<input name="password" type="password" minLength={8} required autoComplete={mode === "signin" ? "current-password" : "new-password"} /></label>}<Button type="submit" className="w-full" disabled={busy}>{busy ? "One moment…" : mode === "signup" ? "Create account" : mode === "signin" ? "Sign in" : mode === "forgot" ? "Send reset link" : "Save new password"}</Button></form>{message && <p role="status" className="mt-4 text-center text-sm text-muted-foreground">{message}</p>}{mode === "signin" && <Button type="button" variant="link" size="sm" className="mx-auto mt-3 flex text-xs text-muted-foreground" onClick={() => setMode("forgot")}>Forgot your password?</Button>}{mode !== "recover" && <Button type="button" variant="link" className="mx-auto mt-3 flex" onClick={() => setMode(mode === "signup" ? "signin" : "signup")}>{mode === "signup" ? "Already have an account? Sign in" : "New here? Create an account"}</Button>}<Link to="/" className="mt-8 block text-center text-xs text-muted-foreground">Back to LinkUp</Link></div></main>;
}