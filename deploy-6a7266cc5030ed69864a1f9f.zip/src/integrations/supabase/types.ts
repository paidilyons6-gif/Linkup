export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      profiles: {
        Row: {
          avatar_path: string | null
          background_image_path: string | null
          background_video_path: string | null
          capture_enabled: boolean
          capture_heading: string
          created_at: string
          current_period_end: string | null
          display_name: string
          id: string
          is_published: boolean
          links: Json
          plan: Database["public"]["Enums"]["linkup_plan"]
          slug: string | null
          social_handle: string
          stripe_customer_id: string | null
          stripe_price_id: string | null
          stripe_subscription_id: string | null
          subscription_status: Database["public"]["Enums"]["subscription_state"]
          tagline: string
          theme: string
          updated_at: string
          welcome_video_path: string | null
        }
        Insert: {
          avatar_path?: string | null
          background_image_path?: string | null
          background_video_path?: string | null
          capture_enabled?: boolean
          capture_heading?: string
          created_at?: string
          current_period_end?: string | null
          display_name?: string
          id: string
          is_published?: boolean
          links?: Json
          plan?: Database["public"]["Enums"]["linkup_plan"]
          slug?: string | null
          social_handle?: string
          stripe_customer_id?: string | null
          stripe_price_id?: string | null
          stripe_subscription_id?: string | null
          subscription_status?: Database["public"]["Enums"]["subscription_state"]
          tagline?: string
          theme?: string
          updated_at?: string
          welcome_video_path?: string | null
        }
        Update: {
          avatar_path?: string | null
          background_image_path?: string | null
          background_video_path?: string | null
          capture_enabled?: boolean
          capture_heading?: string
          created_at?: string
          current_period_end?: string | null
          display_name?: string
          id?: string
          is_published?: boolean
          links?: Json
          plan?: Database["public"]["Enums"]["linkup_plan"]
          slug?: string | null
          social_handle?: string
          stripe_customer_id?: string | null
          stripe_price_id?: string | null
          stripe_subscription_id?: string | null
          subscription_status?: Database["public"]["Enums"]["subscription_state"]
          tagline?: string
          theme?: string
          updated_at?: string
          welcome_video_path?: string | null
        }
        Relationships: []
      }
      public_profiles: {
        Row: {
          avatar_path: string | null
          background_image_path: string | null
          background_video_path: string | null
          capture_enabled: boolean
          capture_heading: string
          display_name: string
          id: string
          is_active: boolean
          is_published: boolean
          links: Json
          slug: string | null
          social_handle: string
          tagline: string
          theme: string
          welcome_video_path: string | null
        }
        Insert: {
          avatar_path?: string | null
          background_image_path?: string | null
          background_video_path?: string | null
          capture_enabled?: boolean
          capture_heading?: string
          display_name?: string
          id: string
          is_active?: boolean
          is_published?: boolean
          links?: Json
          slug?: string | null
          social_handle?: string
          tagline?: string
          theme?: string
          welcome_video_path?: string | null
        }
        Update: {
          avatar_path?: string | null
          background_image_path?: string | null
          background_video_path?: string | null
          capture_enabled?: boolean
          capture_heading?: string
          display_name?: string
          id?: string
          is_active?: boolean
          is_published?: boolean
          links?: Json
          slug?: string | null
          social_handle?: string
          tagline?: string
          theme?: string
          welcome_video_path?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "public_profiles_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      stripe_events: {
        Row: {
          event_id: string
          event_type: string
          processed_at: string
        }
        Insert: {
          event_id: string
          event_type: string
          processed_at?: string
        }
        Update: {
          event_id?: string
          event_type?: string
          processed_at?: string
        }
        Relationships: []
      }
      subscribers: {
        Row: {
          consented_at: string
          created_at: string
          email: string
          id: string
          profile_id: string
          unsubscribed_at: string | null
          updated_at: string
        }
        Insert: {
          consented_at?: string
          created_at?: string
          email: string
          id?: string
          profile_id: string
          unsubscribed_at?: string | null
          updated_at?: string
        }
        Update: {
          consented_at?: string
          created_at?: string
          email?: string
          id?: string
          profile_id?: string
          unsubscribed_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscribers_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      subscribe_to_profile: {
        Args: { _email: string; _slug: string }
        Returns: boolean
      }
    }
    Enums: {
      linkup_plan: "none" | "basic" | "premium" | "business"
      subscription_state:
        | "inactive"
        | "trialing"
        | "active"
        | "past_due"
        | "canceled"
        | "unpaid"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      linkup_plan: ["none", "basic", "premium", "business"],
      subscription_state: [
        "inactive",
        "trialing",
        "active",
        "past_due",
        "canceled",
        "unpaid",
      ],
    },
  },
} as const
