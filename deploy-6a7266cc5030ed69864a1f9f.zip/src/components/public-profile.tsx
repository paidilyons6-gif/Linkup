import { useState, type CSSProperties, type FormEvent } from "react";
import creatorProfile from "@/assets/creator-profile.jpg";
import { supabase } from "@/integrations/supabase/client";
import type { ProfileDisplay } from "@/lib/profile";
import { profileLinks, themes } from "@/lib/profile";

const demo: ProfileDisplay = {
  id: "demo", display_name: "Mia O'Connell", social_handle: "@miamakes", tagline: "Small-batch ceramics made slowly in Dublin.",
  avatar_path: null, background_image_path: null, background_video_path: null, welcome_video_path: null,
  capture_enabled: true, capture_heading: "Studio notes, new drops, no noise.",
  is_published: true, links: [{ label: "Shop the spring drop", url: "#", big: true, note: "New" }, { label: "Book a workshop", url: "#" }, { label: "See the studio", url: "#" }],
  slug: "mia", theme: "sage",
};

export type ProfileMediaUrls = Partial<Record<"avatar_path" | "background_image_path" | "background_video_path" | "welcome_video_path", string>>;

export function PublicProfile({ profile = demo, compact = false, mediaUrls = {} }: { profile?: ProfileDisplay; compact?: boolean; mediaUrls?: ProfileMediaUrls }) {
  const [captureMessage, setCaptureMessage] = useState("");
  const [welcomeFinished, setWelcomeFinished] = useState(false);
  const palette = themes[profile.theme as keyof typeof themes] ?? themes.blush;
  const style = { "--profile-bg": palette.bg, "--profile-accent": palette.accent, "--profile-deep": palette.deep, "--profile-light": palette.light } as CSSProperties;
  const links = profileLinks(profile.links);
  return (
    <main className={`profile-canvas ${compact ? "profile-compact" : ""}`} style={style}>
      <div className="profile-photo" aria-hidden>
        <img src={mediaUrls.background_image_path ?? creatorProfile} alt="" width={1024} height={1536} />
        {mediaUrls.background_video_path && <video src={mediaUrls.background_video_path} autoPlay muted loop playsInline preload="metadata" />}
      </div>
      <div className="profile-veil" />
      <div className="profile-content">
        <img className="profile-avatar" src={mediaUrls.avatar_path ?? creatorProfile} alt={`${profile.display_name} portrait`} width={1024} height={1536} />
        <h1>{profile.display_name || "Your name"}</h1>
        <span className="profile-handle">{profile.social_handle || "@yourhandle"}</span>
        <p>{profile.tagline || "A short line about what you make."}</p>
        <div className="profile-links">
          {links.map((link, index) => <a key={`${link.label}-${index}`} className={`profile-bubble ${link.big ? "is-big" : ""}`} href={link.url || "#"} onClick={compact ? (event) => event.preventDefault() : undefined}><span>{link.label || "New link"}</span>{link.note && <small>{link.note}</small>}</a>)}
        </div>
        {profile.capture_enabled && <form className="profile-capture" onSubmit={async (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); if (compact) return; const email = String(new FormData(event.currentTarget).get("email") ?? ""); const { error } = await supabase.rpc("subscribe_to_profile", { _email: email, _slug: profile.slug ?? "" }); setCaptureMessage(error ? "Please try again." : "You’re on the list."); if (!error) event.currentTarget.reset(); }}><label>{profile.capture_heading}</label><div><input name="email" type="email" required placeholder="Email address" aria-label="Email address" /><button type="submit">Join</button></div>{captureMessage && <p className="mt-2 text-xs">{captureMessage}</p>}</form>}
        <span className="profile-made">Made with LinkUp</span>
      </div>
      {!compact && mediaUrls.welcome_video_path && !welcomeFinished && <div className="welcome-video"><video src={mediaUrls.welcome_video_path} autoPlay playsInline controls onEnded={() => setWelcomeFinished(true)} /><button type="button" onClick={() => setWelcomeFinished(true)}>Skip intro</button></div>}
    </main>
  );
}