import { Link } from "@tanstack/react-router";

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="inline-flex items-center gap-2 font-serif text-xl font-bold text-foreground no-underline">
      <span className="grid size-7 place-items-center rounded-full bg-primary text-xs font-black text-primary-foreground shadow-[0_5px_15px_var(--brand-shadow)]">L</span>
      {!compact && "LinkUp"}
    </Link>
  );
}