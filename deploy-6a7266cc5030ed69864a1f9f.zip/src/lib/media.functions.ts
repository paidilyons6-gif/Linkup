import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const getPublicMediaUrls = createServerFn({ method: "GET" })
  .inputValidator((data) => z.object({ slug: z.string().min(1).max(64) }).parse(data))
  .handler(async ({ data }) => {
    const signingOrigin = process.env["MEDIA_SIGNING_ORIGIN"]?.replace(/\/$/, "");
    if (signingOrigin) {
      const response = await fetch(`${signingOrigin}/api/public/profile-media/${encodeURIComponent(data.slug)}`);
      if (!response.ok) throw new Error("Profile media could not be loaded");
      return z.record(z.string()).parse(await response.json());
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("avatar_path,background_image_path,background_video_path,welcome_video_path")
      .eq("slug", data.slug)
      .eq("is_published", true)
      .neq("plan", "none")
      .in("subscription_status", ["trialing", "active", "past_due"])
      .maybeSingle();

    if (!profile) return {};
    const entries = Object.entries(profile).filter((entry): entry is [keyof typeof profile, string] => typeof entry[1] === "string");
    const resolved = await Promise.all(entries.map(async ([key, path]) => {
      const { data: signed } = await supabaseAdmin.storage.from("profile-media").createSignedUrl(path, 3600);
      return [key, signed?.signedUrl] as const;
    }));
    return Object.fromEntries(resolved.filter((entry) => Boolean(entry[1])));
  });