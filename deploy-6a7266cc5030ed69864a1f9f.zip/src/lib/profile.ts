import type { Json, Tables } from "@/integrations/supabase/types";

export type ProfileLink = { label: string; note?: string; url: string; big?: boolean };
export type ProfileRow = Tables<"profiles">;
export type PublicProfileRow = Tables<"public_profiles">;
export type ProfileDisplay = Pick<
  PublicProfileRow,
  | "id"
  | "slug"
  | "display_name"
  | "social_handle"
  | "tagline"
  | "avatar_path"
  | "welcome_video_path"
  | "background_video_path"
  | "background_image_path"
  | "theme"
  | "links"
  | "capture_enabled"
  | "capture_heading"
  | "is_published"
>;

export const themes = {
  blush: { bg: "#321c2c", accent: "#ff7fb8", deep: "#ef4e97", light: "#ffb3d4" },
  midnight: { bg: "#111827", accent: "#60a5fa", deep: "#2563eb", light: "#bfdbfe" },
  sage: { bg: "#18352b", accent: "#7fc8a9", deep: "#36966f", light: "#c7eadb" },
  amber: { bg: "#3a2513", accent: "#f7b955", deep: "#dc7b24", light: "#ffe0a3" },
  ink: { bg: "#171717", accent: "#a3a3a3", deep: "#525252", light: "#e5e5e5" },
} as const;

export function profileLinks(value: Json): ProfileLink[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is ProfileLink => {
    if (!item || typeof item !== "object" || Array.isArray(item)) return false;
    return typeof item["label"] === "string" && typeof item["url"] === "string";
  });
}