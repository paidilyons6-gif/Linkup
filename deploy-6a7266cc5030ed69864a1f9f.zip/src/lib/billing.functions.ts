import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createCheckout, createPortal } from "./billing.server";

export const startCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ plan: z.enum(["basic", "premium", "business"]) }).parse(input))
  .handler(async ({ data, context }) => {
    const request = getRequest();
    if (!request) throw new Error("Missing request");
    const email = typeof context.claims.email === "string" ? context.claims.email : undefined;
    return createCheckout(context.supabase, context.userId, email, data.plan, new URL(request.url).origin);
  });

export const openBillingPortal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const request = getRequest();
    if (!request) throw new Error("Missing request");
    return createPortal(context.supabase, context.userId, new URL(request.url).origin);
  });