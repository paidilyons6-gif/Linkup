import Stripe from "stripe";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

type Plan = "basic" | "premium" | "business";

function stripeClient() {
  const key = process.env["STRIPE_LIVE_API_KEY"];
  if (!key) throw new Error("Stripe is not configured");
  return new Stripe(key);
}

function priceFor(plan: Plan) {
  const prices: Record<Plan, string | undefined> = {
    basic: process.env["STRIPE_PRICE_BASIC"],
    premium: process.env["STRIPE_PRICE_PREMIUM"],
    business: process.env["STRIPE_PRICE_BUSINESS"],
  };
  const price = prices[plan];
  if (!price) throw new Error(`Stripe price for ${plan} is not configured`);
  return price;
}

export async function createCheckout(
  supabase: SupabaseClient<Database>,
  userId: string,
  email: string | undefined,
  plan: Plan,
  origin: string,
) {
  const { data: profile, error } = await supabase
    .from("profiles")
    .select("stripe_customer_id")
    .eq("id", userId)
    .single();
  if (error) throw error;
  const params: Stripe.Checkout.SessionCreateParams = {
    mode: "subscription",
    payment_method_types: ["card"],
    line_items: [{ price: priceFor(plan), quantity: 1 }],
    client_reference_id: userId,
    metadata: { user_id: userId, plan },
    subscription_data: { metadata: { user_id: userId, plan } },
    automatic_tax: { enabled: true },
    allow_promotion_codes: true,
    success_url: `${origin}/dashboard?paid=1`,
    cancel_url: `${origin}/dashboard`,
  };
  if (profile.stripe_customer_id) params.customer = profile.stripe_customer_id;
  else if (email) params.customer_email = email;
  const session = await stripeClient().checkout.sessions.create(params);
  if (!session.url) throw new Error("Stripe did not return a checkout URL");
  return { url: session.url };
}

export async function createPortal(supabase: SupabaseClient<Database>, userId: string, origin: string) {
  const { data, error } = await supabase.from("profiles").select("stripe_customer_id").eq("id", userId).single();
  if (error) throw error;
  if (!data.stripe_customer_id) throw new Error("No billing account yet");
  const portal = await stripeClient().billingPortal.sessions.create({ customer: data.stripe_customer_id, return_url: `${origin}/dashboard` });
  return { url: portal.url };
}

export function stripeForWebhook() { return stripeClient(); }
export function planFromPrice(priceId: string): Plan | "none" {
  if (priceId === process.env["STRIPE_PRICE_BASIC"]) return "basic";
  if (priceId === process.env["STRIPE_PRICE_PREMIUM"]) return "premium";
  if (priceId === process.env["STRIPE_PRICE_BUSINESS"]) return "business";
  return "none";
}