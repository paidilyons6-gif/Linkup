# LinkUp

A link-in-bio page with a welcome video and your offers as bubbles over a
video of you.

Static site — no build step, no dependencies, no external requests. Drag the
folder onto Netlify, or open `index.html` locally.

## Pages

| | |
|---|---|
| `index.html` | the marketing site: hero, how it works, pricing, FAQ |
| `page.html`  | a customer's public page — welcome video, then bubbles |
| `edit.html`  | the editor, with a live phone preview |

`tokens.css` holds the shared foundations. `site.css` styles the marketing
pages; `linkup.css` styles a customer page. They're separate on purpose — a
customer's theme must never be able to reach the marketing site.

`linkup.js` is the profile shape, the five themes, and the renderer that both
`page.html` and the editor's preview use, so the preview is the page rather
than an impression of it.

## Working now

- Welcome video with a play button, a skip, and automatic hand-off when it ends
- Background video (silent, looping) or a still image
- Bubbles: text, a tag, a link, one that can be made bigger — add, reorder, remove
- Five themes, applied to the page and the browser chrome
- Email capture box
- Live preview that updates as you type

## Backend

Accounts, per-customer addresses, uploads and subscriptions are built. See
**`SETUP.md`** — about an hour of pasting keys into Supabase, Netlify and
Stripe, and it's live.

- `backend/schema.sql` — tables, row-level security, storage, and the single
  function the public read path goes through
- `backend/functions/create-checkout` — starts a Stripe subscription
- `backend/functions/stripe-webhook` — the only thing that ever writes a plan
- `api.js` — the browser's side, written against Supabase's REST API directly
  so the site still loads nothing from a third party
- `config.js` — the two public keys you fill in

## Still not built

- **Sending email to a list.** Business collects addresses and exports them; it
  does not send. That needs a provider, domain authentication, bounce handling,
  GDPR consent records and per-tier send limits.
- **Analytics.** "See what gets tapped" is on the Premium card and isn't real.
- **Video transcoding.** Uploads are capped at 100 MB and served as-is.

## Two things to decide before building further

**The €15 tier is most of the remaining work.** "Unlimited emails to collected
addresses" means running a mailing platform: a sending provider, domain
authentication (SPF/DKIM/DMARC), bounce and complaint handling, and — for an
Irish business — GDPR consent records with a working unsubscribe on every send.
One customer mailing a bought list burns the sending domain for everybody. It's
also where the margin goes: unlimited sending against €15/month is unbounded
cost. Worth a per-tier send limit before the pricing goes public.

**Decide what "your own web address" means.** It's promised on the Premium tier.
A path (`letslinkup.com/becca`) is straightforward. A real custom domain
(`beccalyons.com`) means certificate provisioning per customer, which is a
different amount of work.

## Choices worth knowing

- **No webfont.** The page opens from an Instagram bio on mobile data and has
  one job: be there. A font request to a third party costs a round trip before
  anything renders, and sending EU visitors' IPs to Google before they've
  agreed to anything is the sort of thing that needs a consent banner. The
  system stacks in `tokens.css` are on every device that matters.
- **The welcome video needs a tap.** No browser autoplays video with sound, so
  there's an honest play button rather than a video that silently does nothing.
- **Long labels step down a size.** A circle is unforgiving — "Free calorie
  calculator" has to fit where "Shop" does.
- **Bubble labels carry a shadow.** White text over the pale top of a sphere
  disappears without one.
- **Customer links are sanitised.** Anything that isn't http, https, mailto or
  tel becomes a dead anchor, so a pasted `javascript:` URL can't run on the
  page. This matters the moment strangers can type into it.
- **The background is always muted** — the only way it can autoplay.
- **The CSP in `netlify.toml` is strict** because nothing loads from anywhere
  else. If you add an external script or font later, it will be blocked until
  the policy is updated — that's deliberate.

## Tested

Chromium, at 1440px and at 390px. Marketing page, customer page and editor:
no console errors, no failed requests, no horizontal scroll on mobile, theme
switching applies through to the preview, and no bubble label overflows its
circle.
